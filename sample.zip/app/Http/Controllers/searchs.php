<?php

namespace App\Http\Controllers;
use App\Search;
use Illuminate\Http\Request;

class searchs extends Controller
{
    public function submit(Request $req){
        
        $post = new Search;
        $post -> id = $req->id;
        $post -> name = $req->name;
        $post -> state = $req->state;
        $post -> city = $req->city;
        $post -> addr = $req->address;
        $post -> pincode = $req->pincode;
        $post -> dob = $req->Date_of_birth;
        $post -> mob = $req->Phone_number;
        $post -> blood_group = $req->blood_group;
       
        $post -> save();
        return view('search'); 

    }
}